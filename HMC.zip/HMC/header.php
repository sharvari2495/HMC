<header id="default_header" class="header_style_1">
  <!-- header top -->
  
  <!-- end header top -->
  <!-- header bottom -->
  <div class="header_bottom">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
          <!-- logo start -->
          <div class="logo"> <a href="index.php"><img src="images/logos/logo.png" alt="logo" /></a> </div>
          <!-- logo end -->
        </div>
        <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
          <!-- menu start -->
          <div class="menu_side">
            <div id="navbar_menu">
              <ul class="first-ul">
                <li> <a href="index.php">Home</a>
                  
                </li>
                <li><a href="about.php">About Us</a></li>
                <li> <a href="services.php">Services</a>
                </li>
                <li> <a href="products.php">Products</a> 
                </li>
                
                 <li> <a href="contact.php">Contact</a>
                   </li>
              </ul>
            </div>
            <div class="search_icon">
              <ul>
                <!-- <li><a href="#" data-toggle="modal" data-target="#search_bar"><i class="fa fa-search" aria-hidden="true"></i></a></li> -->
                <li> <a href="registration.php" class="button" type="button">Register &nbsp;&nbsp;&nbsp;&nbsp;</a> 
                </li>
                <li> <a type="button" href="login.php">Login</a>
                </li>
              </ul>
            </div>
          </div>
          <!-- menu end -->
        </div>
      </div>
    </div>
  </div>
  <!-- header bottom end -->
</header>
