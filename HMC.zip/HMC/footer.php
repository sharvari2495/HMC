<footer class="footer_style_2">
  <div class="container-fuild">
    <div class="row">
     
      <div class="footer_blog">
        <div class="row">
          
          <div class="col-md-6">
            <div class="main-heading left_text">
              <h2>About Company</h2>
            </div>
            <p>Established before more than 65 years with gauranteed services.<br>We deal in Machinery Industry. Our main focus is on Agriculutural Products like Pumps, Threshers, Genrators, Rotavator, Spray Pumps.<br>We have different products from different Companies.<br>Best team to provide all the services regarding any product.<br>Our products have affordable rates.<br> 
          </div>
         
          <div class="col-md-6">
            <div class="main-heading left_text">
              <h2>Contact us</h2>
            </div>
            <p>Hyderabad Machinery Company,<br>
              G.G>Road, Tarasingh Market<br>Nanded, Maharashta, India.
              <span style="font-size:18px;"><a href="tel:+9876543210">+919422172003</a></span></p>
            <div class="footer_mail-section">
              <form>
                <fieldset>
                <div class="field">
                  <input placeholder="Email" type="text"> <button class="button_custom"><i class="fa fa-envelope" aria-hidden="true"></i></button>
                </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>
      </div>
      
    </div>
  </div>
</footer>
